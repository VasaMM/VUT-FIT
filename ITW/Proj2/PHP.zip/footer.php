<footer>
	<div class="right">
		&copy; 2016
	</div>
	<div class="left">
		
	</div>
</footer>