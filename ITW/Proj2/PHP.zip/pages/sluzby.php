<div id="sluzby">
	<h2>Výroba:</h2>

	<ul>
		<li><h3>Brány:</h3>
			<ul>
				<li>křídlové</li>
				<li>posuvné</li>
				<li>samonosné</li>
				<li>možnost elektropohonu</li>
			</ul>
		</li>
			<li><h3>Ploty a branky:</h3>
			<ul>
				<li>plotové výplně</li>
				<li>klasické popř. kovářské nebo jen s kovářskými prvky</li>
			</ul>
		</li>
		<li><h3>Zábradlí:</h3>
			<ul>
				<li>klasické</li>
				<li>okrasné s kovářskými prvky</li>
			</ul>
		</li>
		<li><h3>Anténní stožáry a výložníky</h3></li>
		<li><h3>Údržbářské práce a opravy</h3></li>
	</ul>


	<h2>Montáž:</h2>
		<p>Montáž provedeme dle přání zákazníka.</p>

	<h2>Na naše výrobky zajistíme povrchovou úpravu:</h2>
		<ul>
			<li>Žárové zinkování</li>
			<li>Galvanické zinkování</li>
			<li>Práškové lakování - komaxit</li>
		</ul>
</div>