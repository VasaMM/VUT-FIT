<aside id="left-column">
	<section id="kontakt">
		<h2>Kontakt</h2>
		<adress>	
			<h3>Adresa</h3>
				<div class="adress">
					Toveř 191<br>
					Toveř<br>
					779 00<br>
					<a href="https://mapy.cz/s/CPZT" class="maps">Odkaz na mapy.cz</a>
				</div>
	    
	        <h3>Telefon</h3>
				<div class="phone">+420 605 807 892</div>
			
			<h3>E-mail</h3>
				<div class="email">
					<a href="mailto:martinka-zam@seznam.cz">martinka-zam@seznam.cz</a>
				</div>
		</address>
	</section>
	<section id="mapa-stranek">
		<h2>Mapa stránek</h2>
		<div id="site-map">
			<?php include("menu.php"); ?>
		</div>	
		<div class="hide-but" id="site-map-but"></div>
	</section>

	<!--
	<section style="display: none">
		<h2>Statistika</h2>
		<div class="to-hide" id="stat">
			<a href="http://www.toplist.cz/stat/1147781">
				<script language="JavaScript" type="text/javascript">
					document.write('<img src="https://toplist.cz/count.asp?id=1147781&logo=mc&http='+escape(document.referrer)+'&t='+escape(document.title)+'&wi='+escape(window.screen.width)+'&he='+escape(window.screen.height)+'&cd='+escape(window.screen.colorDepth)+'" width="88" height="60" border=0 alt="TOPlist" />'); 
				</script>
				<noscript>
					<img src="https://toplist.cz/count.asp?id=1147781&logo=mc" border="0" alt="TOPlist" width="88" height="60" />
				</noscript>
			</a><br>
		</div>
		<div class="hide-but" id="stat-but"></div>
	</section>
	-->
</aside>