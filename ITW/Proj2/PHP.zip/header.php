<div class="top">
<div class="inner">
	<header>
		<a class="logo" href="http://www.stud.fit.vutbr.cz/~xmarti76/">
			<h1>Zámečnictví</h1>
			<h2>Marek Martinka</h2>
		</a>
	</header>
	
	<!-- https://www.iconfinder.com/icons/106200/menu_icon#size=128 -->
	<img src="pictures/menu.png" id="menu-btn" alt="menu" width="0" height="0">
	<nav id="main-menu">
		<?php include("menu.php"); ?>
	</nav>
</div>
</div>	
